const path = require('path');
require('module-alias').addAliases({
  '@configs': path.join(__dirname, '../configs'),
  '@controllers': path.join(__dirname, '../controllers'),
  '@errors': path.join(__dirname, '../errors'),
  '@middlewares': path.join(__dirname, '../middlewares'),
  '@models': path.join(__dirname, '../models'),
  '@modules': path.join(__dirname, '../modules'),
  '@routers': path.join(__dirname, '../routers'),
  '@utils': path.join(__dirname, '../utils'),
});
