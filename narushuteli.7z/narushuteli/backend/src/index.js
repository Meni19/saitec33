require('dotenv').config();
require('./utils/aliases');
require('@configs/dbAssociations');
const PORT = process.env.PORT || 5000;
const CORS_ORIGIN = process.env.CORS_ORIGIN;
const express = require('express');
const cors = require('cors');
const fileUpload = require('express-fileupload');
const sequelize = require('@configs/dbAuth');
const router = require('@configs/apiRouters');
const errorHandler = require('@middlewares/errorHandler');

const app = express();
app.use(cors(CORS_ORIGIN));
app.use(express.json());
app.use(fileUpload({}));
app.use('/api', router);
app.use(errorHandler);

const start = async () => {
  try {
    await sequelize.authenticate();
    await sequelize.sync();
    app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
  } catch (e) {
    console.log(e);
  }
};

start();
