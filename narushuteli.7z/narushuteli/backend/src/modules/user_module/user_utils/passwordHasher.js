const bcrypt = require('bcrypt');

module.exports = async function hashPassword(password) {
  const hashedPassword = await bcrypt.hash(password, 5);
  return hashedPassword;
};
