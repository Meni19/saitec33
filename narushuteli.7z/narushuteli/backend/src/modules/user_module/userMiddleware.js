const bcrypt = require('bcrypt');
const { User } = require('./userModel');

// Валидации полей

async function fieldsValidation(full_name, phone, login, email, password) {
  if (!full_name || !phone || !email || !login || !password) {
    throw new Error('Не все обязательные поля заполнены');
  }
}

// Валидации имени

async function fullNameFieldValidation(full_name) {
  if (!full_name) {
    throw new Error('Имя должно быть заполнено');
  }
}

async function fullNameValidation(full_name) {
  const checkFullNameRegex =
    /^[a-zA-Zа-яА-ЯёЁ]+\s[a-zA-Zа-яА-ЯёЁ]+\s[a-zA-Zа-яА-ЯёЁ]+$/;
  if (!checkFullNameRegex.test(full_name)) {
    throw new Error('Некорректный формат имени');
  }
}

// Валидации номера телефона

async function phoneFieldValidation(phone) {
  if (!phone) {
    throw new Error('Номер телефона должен быть заполнен');
  }
}

async function phoneValidation(phone) {
  const checkPhoneRegex = /^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/; // Russian phone number format: +7(XXX)-XXX-XX-XX
  if (!checkPhoneRegex.test(phone)) {
    throw new Error('Некорректный формат номера телефона');
  }
}

// Валидации логина

async function loginFieldValidation(login) {
  if (!login) {
    throw new Error('Логин должен быть заполнен');
  }
}

async function loginLengthValidation(login) {
  if (login.length < 6) {
    throw new Error('Логин должен быть не менее 6 символов');
  }
}

async function uniqueLoginValidation(login) {
  const checkLogin = await User.findOne({ where: { login } });
  if (checkLogin) {
    throw new Error('Пользователь с таким логином уже существует');
  }
}

// Валиации электронной почты

async function emailFieldValidation(email) {
  if (!email) {
    throw new Error('Почта должна быть заполнена');
  }
}

async function emailValidation(email) {
  const checkEmailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!checkEmailRegex.test(email)) {
    throw new Error('Некорректный формат почты');
  }
}

// Валидации пароля

async function passwordLengthValidation(password) {
  if (password.length < 6) {
    throw new Error('Пароль должен быть не менее 6 символов');
  }
}

async function confirmPasswordValidation(password, confirm_password) {
  if (password !== confirm_password) {
    throw new Error('Пароль и подтверждение пароля не совпадают');
  }
}

async function passwordFieldValidation(password) {
  if (!password) {
    throw new Error('Пароль должен быть заполнен');
  }
}

async function confirmPasswordFieldValidation(confirm_password) {
  if (!confirm_password) {
    throw new Error('Подтверждение пароля дольжно быть заполнено');
  }
}

// Валидации роли

async function roleValidation(role) {
  if (role !== 'ADMIN' && role !== 'USER' && role !== undefined) {
    throw new Error('Некорректная роль');
  }
}

// Валидации при логине

async function loginValidate(login, password) {
  const user = await User.findOne({ where: { login } });
  if (!user) {
    throw new Error('Пользователь не найден');
  }

  const comparePassword = bcrypt.compareSync(password, user.password);
  if (!comparePassword) {
    throw new Error('Указан неверный пароль');
  }

  return user;
}

module.exports = {
  fieldsValidation,
  fullNameFieldValidation,
  fullNameValidation,
  phoneFieldValidation,
  phoneValidation,
  loginFieldValidation,
  loginLengthValidation,
  uniqueLoginValidation,
  emailFieldValidation,
  emailValidation,
  passwordLengthValidation,
  confirmPasswordValidation,
  passwordFieldValidation,
  confirmPasswordFieldValidation,
  roleValidation,
  loginValidate,
};
