const Router = require('express');
const router = new Router();
const UserController = require('./userController');
const authHandler = require('@middlewares/authHandler');

router.post('/registration', UserController.registration);
router.post('/login', UserController.login);
router.get('/auth', authHandler, UserController.auth);

module.exports = router;
