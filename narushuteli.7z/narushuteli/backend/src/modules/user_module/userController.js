const ApiError = require('@errors/apiError');
const { User } = require('./userModel');
const userMiddleware = require('./userMiddleware');
const hashPassword = require('./user_utils/passwordHasher');
const generateJwt = require('./user_utils/jwtGenerator');

class UserController {
  async registration(req, res, next) {
    try {
      const {
        full_name,
        phone,
        email,
        login,
        password,
        confirm_password,
        role,
      } = req.body;
      await userMiddleware.fieldsValidation(
        full_name,
        phone,
        login,
        email,
        password,
      );
      await userMiddleware.fullNameValidation(full_name);
      await userMiddleware.phoneValidation(phone);
      await userMiddleware.uniqueLoginValidation(login);
      await userMiddleware.loginLengthValidation(login);
       // await userMiddleware.emailValidation(email);
      await userMiddleware.passwordLengthValidation(password);
      await userMiddleware.confirmPasswordFieldValidation(confirm_password);
      await userMiddleware.confirmPasswordValidation(
        password,
        confirm_password,
      );
      await userMiddleware.roleValidation(role);
      const hashedPassword = await hashPassword(password);
      const user = await User.create({
        full_name,
        phone,
        email,
        login,
        password: hashedPassword,
        role,
      });
      const token = generateJwt(user.id, user.email, user.role);
      return res.json({ token });
    } catch (error) {
      next(ApiError.badRequest(error.message));
    }
  }


  
  async login(req, res, next) {
    try {
      const { login, password } = req.body;
      const user = await userMiddleware.loginValidate(login, password);
      const token = generateJwt(user.id, user.email, user.role);
      return res.json({ token });
    } catch (error) {
      next(ApiError.badRequest(error.message));
    }
  }
  async auth(req, res, next) {
    try {
      const token = generateJwt(req.user.id, req.user.email, req.user.role);
      return res.json({ token });
    } catch (error) {
      next(ApiError.badRequest(error.message));
    }
  }
}


module.exports = new UserController();
