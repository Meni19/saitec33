const ApiError = require('@errors/apiError');
const { Ticket } = require('./ticketModel');
const ticketMiddleware = require('./ticketMiddleware');

class TicketController {
  async create(req, res, next) {
    try {
      const userId = req.params.userId;
      const { car_number, offence } = req.body;
      await ticketMiddleware.userExistsValidation(userId);
      await ticketMiddleware.carNumberValidation(car_number);
      await ticketMiddleware.offenceValidation(offence);
      const ticket = await Ticket.create({
        car_number,
        offence,
        userId,
      });
      return res.json({ ticket });
    } catch (error) {
      next(ApiError.badRequest(error.message));
    }
  }

  async getByUser(req, res, next) {
    try {
      const userId = req.params.userId;
      await ticketMiddleware.userExistsValidation(userId);
      const tickets = await Ticket.findAll({ where: { userId } });
      return res.json({ tickets });
    } catch (error) {
      next(ApiError.badRequest(error.message));
    }
  }
  async getAll(req, res, next) {
    try {
      const tickets = await Ticket.findAll();
      return res.json({ tickets });
    } catch (error) {
      next(ApiError.badRequest(error.message));
    }
  }

  async setConfirmed(req, res, next) {
    try {
      const ticketId = req.params.ticketId;
      const ticket = await Ticket.findByPk(ticketId);
      await ticketMiddleware.ticketExistsValidation(ticketId);
      ticket.status = 'CONFIRMED';
      await ticket.save();
      return res.json({ ticket });
    } catch (error) {
      next(ApiError.badRequest(error.message));
    }
  }

  async setDenied(req, res, next) {
    try {
      const ticketId = req.params.ticketId;
      const ticket = await Ticket.findByPk(ticketId);
      await ticketMiddleware.ticketExistsValidation(ticketId);
      ticket.status = 'DENIED';
      await ticket.save();
      return res.json({ ticket });
    } catch (error) {
      next(ApiError.badRequest(error.message));
    }
  }
}

module.exports = new TicketController();
