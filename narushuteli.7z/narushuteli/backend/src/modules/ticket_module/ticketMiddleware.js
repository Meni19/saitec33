const { Ticket } = require('./ticketModel');
const { User } = require('@modules/user_module/userModel');

async function userExistsValidation(userId) {
  const user = await User.findByPk(userId);
  if (!user) {
    throw new Error('Пользователь не найден');
  }
}

async function carNumberValidation(car_number) {
  if (!car_number) {
    throw new Error('Номер автомобиля должен быть заполнен');
  }

  const checkCarNumberRegex = /^[А-Я]\d{3}[А-Я]{2}\d{2,3}$/;
  if (!checkCarNumberRegex.test(car_number)) {
    throw new Error('Некорректный формат номера автомобиля');
  }
}

async function offenceValidation(offence) {
  if (!offence) {
    throw new Error('Нарушение должно быть заполнено');
  }
}

async function ticketExistsValidation(ticketId) {
  const ticket = await Ticket.findByPk(ticketId);
  if (!ticket) {
    throw new Error('Билет не найден');
  }
}

module.exports = {
  userExistsValidation,
  carNumberValidation,
  offenceValidation,
  ticketExistsValidation,
};
