const Router = require('express');
const router = new Router();
const TicketController = require('./ticketController');
const roleHandler = require('@middlewares/roleHandler');

router.post('/:userId', TicketController.create);
router.get('/:userId', TicketController.getByUser);
router.get('/', TicketController.getAll);
router.put(
  '/confirmed/:ticketId',
  roleHandler('ADMIN'),
  TicketController.setConfirmed,
);
router.put(
  '/denied/:ticketId',
  roleHandler('ADMIN'),
  TicketController.setDenied,
);

module.exports = router;
