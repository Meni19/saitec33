const sequelize = require('@configs/dbAuth');
const { DataTypes } = require('sequelize');

const Ticket = sequelize.define('ticket', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  car_number: { type: DataTypes.STRING, allowNull: false },
  offence: { type: DataTypes.TEXT, allowNull: false },
  status: { type: DataTypes.STRING, allowNull: false, defaultValue: 'NEW' },
});

module.exports = { Ticket };
