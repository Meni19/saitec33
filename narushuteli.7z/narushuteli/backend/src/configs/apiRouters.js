const Router = require('express');
const router = new Router();

const userRouter = require('@modules/user_module/userRouter');
const ticketRouter = require('@modules/ticket_module/ticketRouter');

router.use('/user', userRouter);
router.use('/ticket', ticketRouter);

module.exports = router;
