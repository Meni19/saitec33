const { User } = require('@modules/user_module/userModel');
const { Ticket } = require('@modules/ticket_module/ticketModel');

User.hasMany(Ticket);
Ticket.belongsTo(User);

module.exports = { User, Ticket };
