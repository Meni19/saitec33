const path = require('path');
const resolvePath = (p) => path.resolve(__dirname, p);

module.exports = {
  webpack: {
    alias: {
      '@src': resolvePath('./src'),
      '@api': resolvePath('./src/api'),
      '@components': resolvePath('./src/components'),
      '@render': resolvePath('./src/render'),
      '@store': resolvePath('./src/store'),
      '@views': resolvePath('./src/views'),
    },
  },
};
