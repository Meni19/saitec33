import React, { useState, useEffect } from 'react';
import Accordion from 'react-bootstrap/Accordion';
import { getUserTickets } from '@api/ticketApi';
import './userTicketsStyles.scss'; // Import your CSS file

function UserTickets() {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const userId = localStorage.getItem('userId');

  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const response = await getUserTickets(userId);
        const data = response.tickets;
        setTickets(data);
        setLoading(false);
      } catch (error) {
        console.error('Ошибка при при получении обращений:', error);
        setLoading(false);
      }
    };

    fetchTickets();
  }, [userId]);

  if (loading) {
    return <p className="user-tickets-loading">Загрузка...</p>;
  }

  return (
  
    <div id="user-tickets">
      <h2 className="user-tickets-title">Мои обращения</h2>
      {tickets.length === 0 ? (
        <p className="none-tickets">Обращений пока нет</p>
      ) : (
        <ul className="user-tickets-list">
          {tickets
            .slice()
            .reverse()
            .map((ticket) => (
              <li className="user-tickets-list-item" key={ticket.id}>
                <div className="user-ticket-main-info">
                  <p className="user-tickets-list-item-car-number">
                    Номер автомобиля: {ticket.car_number}
                  </p>
                  <p
                    className={`user-tickets-list-item-status ${ticket.status === 'NEW' ? 'new-status' : ticket.status === 'DENIED' ? 'denied-status' : 'confirmed-status'}`}
                  >
                    {ticket.status === 'NEW'
                      ? 'Создано'
                      : ticket.status === 'DENIED'
                        ? 'Отклонено'
                        : 'Принято'}
                  </p>
                </div>
                {/* <p className="user-tickets-list-item-offence-title">
                Описание нарушения: 
              </p>
              <p className="user-tickets-list-item-offence">{ticket.offence}</p> */}
                <Accordion>
                  <Accordion.Item eventKey="0">
                    <Accordion.Header className="user-tickets-list-item-offence-title">
                      Описание нарушения:
                    </Accordion.Header>
                    <Accordion.Body className="user-tickets-list-item-offence">
                      {ticket.offence}
                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>
                <hr />
              </li>
            ))}
        </ul>
      )}
    </div>
  );
}

export default UserTickets;
