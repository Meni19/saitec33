import './headerStyles.scss';
import { useContext, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Context } from '@src/index';

function Header() {
  const { user } = useContext(Context);
  const location = useLocation();

  const handleLogout = () => {
    user.setUser({});
    user.setIsAuth(false);
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
  };

  const isAdmin = user.isAuth && user.user && user.user.role === 'ADMIN';

  const navItems = [
    // { path: '/', title: 'Главная страница' },
    {
      path: '/user',
      title: 'Мои обращения',
      visible: user.isAuth,
    },
    { path: '/signup', title: 'Регистрация', visible: !user.isAuth },
    {
      path: '/signin',
      title: user.isAuth ? 'Выйти' : 'Войти',
      onClick: user.isAuth ? handleLogout : null,
    },

    isAdmin && {
      path: '/admin',
      title: 'Админ панель',
    },
  ].filter((item) => item);

  useEffect(() => {}, [user.user]);

  return (
    <div id="header-wrapper">
        
        <Link className="nav-item-passive" to="/">
      <img className='logo' src='/images/logo.png' alt='Logo' />
      </Link>
      
    

      {navItems.map(
        ({ path, title, onClick, visible }) =>
          visible !== false && (
            <li
              className={`nav-item ${
                location.pathname === path
                  ? 'nav-item-active'
                  : 'nav-item-passive'
              }`}
              key={path}
            >
              {location.pathname === path ? (
                <div className="nav-item-active">{title}</div>
              ) : (
                <Link className="nav-item-passive" to={path} onClick={onClick}>
                  {title}
                </Link>
              )}
            </li>
          ),
      )}
    </div>
  );
}

export default Header;
