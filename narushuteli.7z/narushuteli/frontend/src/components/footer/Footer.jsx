import "./FooterStyles.css";
import { Link } from "react-router-dom";

function Footer() {
  return (
    <div className="footer">
      <div className="items">
        <div className="logo">

        </div>
        <Link className="contacts" to="/contacts">
          Контакты
        </Link>
        {/* <Link className="about" to="/about">
          О нас
        </Link> */}
        <div className="title">@2024 Narusheniy.net </div>

      </div>
    </div>
  );
}

export default Footer;
