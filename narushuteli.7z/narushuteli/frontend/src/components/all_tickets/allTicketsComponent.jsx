import './allTicketsStyles.scss';
import Button from 'react-bootstrap/Button';
import Accordion from 'react-bootstrap/Accordion';
import React, { useState, useEffect } from 'react';
import { getAllTickets, setConfirmed, setDenied } from '@api/ticketApi';

function AllTickets() {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const response = await getAllTickets();
        const data = response.tickets;
        setTickets(data);
        setLoading(false);
      } catch (error) {
        console.error('Ошибка при получении обращений:', error);
        setLoading(false);
      }
    };

    fetchTickets();
  }, []);

  const handleConfirm = async (ticketId) => {
    try {
      await setConfirmed(ticketId);
      setTickets((prevTickets) =>
        prevTickets.map((ticket) =>
          ticket.id === ticketId ? { ...ticket, status: 'CONFIRMED' } : ticket,
        ),
      );
    } catch (error) {
      console.error('Ошибка при подтверждении обращения:', error);
    }
  };

  const handleDeny = async (ticketId) => {
    try {
      await setDenied(ticketId);
      setTickets((prevTickets) =>
        prevTickets.map((ticket) =>
          ticket.id === ticketId ? { ...ticket, status: 'DENIED' } : ticket,
        ),
      );
    } catch (error) {
      console.error('Ошибка при отклонении обращения:', error);
    }
  };

  if (loading) {
    return <p>Загрузка...</p>;
  }

  return (
    <div id="user-tickets">
      <h2 className="user-tickets-title">Все обращения</h2>
      {tickets.length === 0 ? (
        <p className="none-tickets">Нет обращений</p>
      ) : (
        <ul className="user-tickets-list">
          {tickets.map((ticket) => (
            <li className="all-tickets-list" key={ticket.id}>
              <p>Номер автомобиля: {ticket.car_number}</p>
              <Accordion>
                <Accordion.Item eventKey="0">
                  <Accordion.Header>Нарушение:</Accordion.Header>
                  <Accordion.Body>{ticket.offence}</Accordion.Body>
                </Accordion.Item>
              </Accordion>
              {/* <p>Нарушение: {ticket.offence}</p> */}
              <p
                className={`status ${ticket.status === 'NEW' ? 'new-status' : ticket.status === 'DENIED' ? 'denied-status' : 'confirmed-status'}`}
              >
                {ticket.status === 'NEW'
                  ? 'Новый'
                  : ticket.status === 'DENIED'
                    ? 'Отклонен'
                    : 'Принят'}
              </p>
              <Button
                className="button"
                variant="success"
                onClick={() => handleConfirm(ticket.id)}
              >
                Подтвердить
              </Button>
              <Button variant="danger" onClick={() => handleDeny(ticket.id)}>
                Отклонить
              </Button>
              <hr />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default AllTickets;
