function Ticket() {
  return <div id="ticket"></div>;
}

export default Ticket;
