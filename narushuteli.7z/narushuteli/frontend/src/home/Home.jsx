import React from "react";
import { Link } from "react-router-dom";
import "./HomeStyles.css";

function Home() {
  return (
    <div id="mainScreen">
      <h2 className="section-title">Kompik33 — Лучшие готовые решения</h2>
      <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Сборки для любых задач:</h3>

      <div className="car-card">
        <div className="car-image">
          <div>
            <div>
              <img src="/images/auto/1.jpg" alt="auto"/>
            </div>
            <Link to="/store">
              Узнать больше
            </Link>
          </div>
        </div>

        <div className="car-details">
          <h3 className="car-title">Purple EVO 2.0</h3>
          <p className="car-description">
          
        Премиальная основа на базе i9 14900KF и RTX 4090 с использованием топовых комплектующих от MSI и Deepcool. 
        Оптимизирован под ААА и онлайн-проекты.{" "}
          </p>
          <div className="car-price">
            <span className="car-price-new">450,000 рублей</span>
            <span className="car-price-old">465,000 рублей</span>
          </div>
        </div>
      </div>

      <div className="car-card">
        <div className="car-image">
          <div>
            <div>
            <img src="/images/auto/2.jpg" alt="auto"/>
            </div>
            <Link to="/store">
              Узнать больше
            </Link>
          </div>
        </div>

        <div className="car-details">
          <h3 className="car-title">White HYTE</h3>
          <p className="car-description">
          Система на базе процессора i9 13900K и видеокарты RTX 4090 24 GB в эксклюзивном корпусе с панорамным обзором на комплектующие.
          </p>
          <div className="car-price">
            <span className="car-price-new">440,000 рублей</span>
            <span className="car-price-old">450,000 рублей</span>
          </div>
        </div>
      </div>

      <div className="car-card">
        <div className="car-image">
          <div>
            <div>
            <img src="/images/auto/3.jpg" alt="auto"/>
            </div>
            <Link to="/store">
              Узнать больше
            </Link>
          </div>
        </div>

        <div className="car-details">
          <h3 className="car-title">ICON North</h3>
          <p className="car-description">
          Технологии в стиле Лофт.
Корпус ПК выполнен в минималистичном стиле с использованием настоящего дуба и кожи, 
такое сочетание не оставит равнодушным настоящего ценителя роскоши. Начинка компьютера соответствует, 
связка 20-ти ядерного i7 14700K и RTX 4080 Super 16 GB обеспечит своего владельца максимальной производительностью в игровых и рабочих задачах.
          </p>
          <div className="car-price">
            <span className="car-price-new">300,000 ₽ рублей</span>
            <span className="car-price-old">312,000 рублей</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
