import { $authHost } from './index';

export const createTicket = async (userId, car_number, offence) => {
  const { data } = await $authHost.post(`api/ticket/${userId}`, {
    car_number,
    offence,
  });
  return data;
};

export const getUserTickets = async (userId) => {
  const { data } = await $authHost.get(`api/ticket/${userId}`);
  return data;
};

export const getAllTickets = async () => {
  const { data } = await $authHost.get('api/ticket');
  return data;
};

export const setConfirmed = async (ticketId) => {
  const { data } = await $authHost.put(`api/ticket/confirmed/${ticketId}`);
  return data;
};

export const setDenied = async (ticketId) => {
  const { data } = await $authHost.put(`api/ticket/denied/${ticketId}`);
  return data;
};
