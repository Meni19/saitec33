import Header from '@components/header/headerComponent';
// import Footer from '@components/footer/footerComponent';
import PagesRoutes from './pagesRoutes';

function Layout() {
  return (
    <div id="layout">
      <Header />
      <PagesRoutes />
      {/* <Footer /> */}
    </div>
  );
}

export default Layout;
