import { Route, Routes } from 'react-router-dom';
import AdminPanel from '@views/admin_panel/adminPanelView';
// import HomePage from '@views/home_page/homePageView';
import SignIn from '@views/sign_in/signInView';
import SignUp from '@views/sign_up/signUpView';
import TicketCreate from '@views/ticket_create/ticketCreateView';
import UserProfile from '@views/user_profile/userProfileView';
import NotFound from '@views/not_found/notFoundView';

function PagesRoutes() {
  return (
    <div id="pages-routes">
      <Routes>
        <Route path="/admin" element={<AdminPanel />} />
        {/* <Route path="/" element={<HomePage />} /> */}
        <Route path="/" element={<SignIn />} />
        <Route path="/signin" element={<SignIn />} />

        <Route path="/signup" element={<SignUp />} />
        <Route path="/ticket" element={<TicketCreate />} />
        <Route path="/user" element={<UserProfile />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </div>
  );
}

export default PagesRoutes;
