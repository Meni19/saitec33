import './signInStyles.scss';
import Alert from 'react-bootstrap/Alert';
import { useState, useContext } from 'react';
import { Form, Button } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { observer } from 'mobx-react-lite';
import { login } from '@api/userApi';
import { Context } from '@src/index';

import Footer from '../../components/footer/Footer.jsx';
const SignIn = observer(() => {
  const { user } = useContext(Context);

  const [allFieldsFilled, setAllFieldsFilled] = useState(false);

  const [userLogin, setUserLogin] = useState('');
  const [password, setPassword] = useState('');

  const [errorText, setErrorText] = useState('');

  const navigate = useNavigate();

  const handleFormChange = () => {
    const formInputs = document.querySelectorAll('.form-input');
    let allFilled = true;
    formInputs.forEach((input) => {
      if (input.value === '') {
        allFilled = false;
      }
    });
    setAllFieldsFilled(allFilled);
  };

  const loginclick = async () => {
    try {
      let data = await login(userLogin, password);
      user.setUser(data);
      user.setIsAuth(true);
      localStorage.setItem('userId', data.id);
      navigate('/user');
      setErrorText('');
    } catch (error) {
      setErrorText(error.response.data.message);
    }
  };

  return (
    <div id="auth-form">
      <h1>Авторизация</h1>
      <p className="form-title">Введите логин </p>
      <Form.Control
        className="form-input"
        type="text"
        placeholder="Логин"
        value={userLogin}
        onChange={(e) => {
          setUserLogin(e.target.value);
          handleFormChange();
        }}
      />
      <p className="form-title">Введите пароль</p>
      <Form.Control
        className="form-input"
        type="password"
        placeholder="Пароль"
        value={password}
        onChange={(e) => {
          setPassword(e.target.value);
          handleFormChange();
        }}
      />
      {errorText && (
        <Alert variant="danger" className="form-error-message">
          {errorText}
        </Alert>
      )}
      <Button style = {{Color: 'purple'}}
        className="form-button"
        variant={allFieldsFilled ? 'outline-success' : 'outline-primary'}
        disabled={!allFieldsFilled}
        onClick={loginclick}
      >
        Войти
      </Button >{' '}
      <Link className="form-registration-link" to="/signup">
        <Button variant="secondary" style = {{backgroundColor: 'teal'}} >Регистрация</Button>
      </Link>
      <Footer />
    </div>
    
  );
});

export default SignIn;
