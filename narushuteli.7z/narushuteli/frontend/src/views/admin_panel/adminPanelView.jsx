import './adminPanelStyles.scss';
import { useContext } from 'react';

import { Navigate } from 'react-router-dom';

import { Context } from '@src/index';

import AllTickets from '@components/all_tickets/allTicketsComponent';



function AdminPanel() {
  const { user } = useContext(Context);
  if (!(user.user.role === 'ADMIN')) {
    return <Navigate to="/" />;
  }
  return (
    <div className="admin">
      <AllTickets />;
      
    </div>
    
  );
}

export default AdminPanel;
