import React, { useState } from 'react';
import Alert from 'react-bootstrap/Alert';
import { createTicket } from '@api/ticketApi';
import './ticketCreateStyles.scss';

function TicketCreate() {
  const [carNumber, setCarNumber] = useState('');
  const [offence, setOffence] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const userId = localStorage.getItem('userId');
      await createTicket(userId, carNumber, offence);
      setCarNumber('');
      setOffence('');
      alert('Обращение успешно создано!');
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="ticket-create-container">
      <div className="ticket-create-form">
        <h2>Создать обращение</h2>
        <form onSubmit={handleSubmit}>
          <div>
            <label>Введите номер автомобиля нарушителя:</label>
            <input
              type="text"
              placeholder="A123БВ45"
              value={carNumber}
              onChange={(e) => setCarNumber(e.target.value)}
              required
            />
          </div>
          <div>
            <label>Описание нарушения:</label>
            <textarea
              value={offence}
              onChange={(e) => setOffence(e.target.value)}
              required
            />
          </div>
          <button type="submit" disabled={loading}>
            {loading ? 'Отправка...' : 'Отправить обращение'}
          </button>
        </form>
        {error && (
          <Alert variant="danger" className="form-error-message">
            Неправильный формат номера
          </Alert>
        )}
      </div>
    </div>
  );
}

export default TicketCreate;
