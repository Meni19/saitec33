import './userProfileStyles.scss';
import { Link } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import UserTickets from '@components/user_tickets/userTicketsComponent';


function UserProfile() {
  return (
    <div id="user-profile">
      <Link className="create-ticket-button" to="/ticket">
        <Button className="create-ticket-button-btn" variant="success" style = {{backgroundColor: 'teal'}}>
          Подать обращение
        </Button>
      </Link>
      <UserTickets />
      
    </div>
    
  );
}

export default UserProfile;
