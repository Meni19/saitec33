import './signUpStyles.scss';
import Alert from 'react-bootstrap/Alert';

import { useState, useEffect, useCallback, useContext } from 'react';
import { Form, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { observer } from 'mobx-react-lite';
import { registration } from '@api/userApi';
import { Context } from '@src/index';

// если че поменяй путь
import Footer from '../../components/footer/Footer.jsx';

const SignUp = observer(() => {
  const { user } = useContext(Context);
  const navigate = useNavigate();

  const [allFieldsFilled, setAllFieldsFilled] = useState(false);
  const [full_name, setFullName] = useState('');
  const [login, setLogin] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm_password, setConfirmPassword] = useState('');

  const [errorText, setErrorText] = useState('');

  const handleFormChange = useCallback(() => {
    const formInputs = document.querySelectorAll('.form-input');
    let allFilled = true;
    formInputs.forEach((input) => {
      if (input.value === '') {
        allFilled = false;
      }
    });
    setAllFieldsFilled(allFilled);
  }, []);

  useEffect(() => {
    handleFormChange();
  }, [handleFormChange]);

  const formatPhoneNumber = (input) => {
    // Remove non-digit characters
    const digits = input.replace(/\D/g, '');

    // Limit to maximum 11 digits
    const maxLength = 11;
    const truncatedDigits = digits.slice(0, maxLength);

    // Format the truncated digits
    const formatted = truncatedDigits.replace(
      /^(\d{1})(\d{3})(\d{3})(\d{2})(\d{2})$/,
      '+$1($2)-$3-$4-$5',
    );

    return formatted;
  };

  const signUpClick = async () => {
    try {
      let data = await registration(
        full_name,
        formatPhoneNumber(phone), // Format phone number before sending
        email,
        login,
        
        password,
        confirm_password,
      );
      user.setUser(data.user);
      user.setIsAuth(true);
      navigate('/signin');
      setErrorText('');
    } catch (error) {
      setErrorText(error.response.data.message);
    }
  };

  return (
    <div id="auth-form">
      <h1>Регистрация</h1>
      <p className="form-title">Введите полное ФИО</p>
      <Form.Control
        className="form-input"
        type="text"
        placeholder="Максимов Максим Максимович"
        value={full_name}
        onChange={(e) => {
          setFullName(e.target.value);
          handleFormChange();
        }}
      />
      <p className="form-title">Введите логин</p>
      <Form.Control
        className="form-input"
        type="text"
        placeholder="Например Maksim"
        value={login}
        onChange={(e) => {
          setLogin(e.target.value);
          handleFormChange();
        }}
      />
      <p className="form-title">Введите номер телефона</p>
      <Form.Control
        className="form-input"
        type="text"
        placeholder="Телефон"
        value={formatPhoneNumber(phone)}
        onChange={(e) => {
          setPhone(e.target.value);
          handleFormChange();
        }}
      />
      <p className="form-title">Введите электронную почту</p>
      <Form.Control
        className="form-input"
        type="text"
        placeholder="example@gmail.com"
        value={email}
        onChange={(e) => {
          setEmail(e.target.value);
          handleFormChange();
        }}
      />
      <p className="form-title">Введите пароль</p>
      <Form.Control
        className="form-input"
        type="password"
        placeholder="Пароль"
        value={password}
        onChange={(e) => {
          setPassword(e.target.value);
          handleFormChange();
        }}
      />
      <p className="form-title">Введите подтверждение пароля</p>
      <Form.Control
        className="form-input"
        type="password"
        placeholder="Повторите пароль"
        value={confirm_password}
        onChange={(e) => {
          setConfirmPassword(e.target.value);
          handleFormChange();
        }}
      />
      {errorText && (
        <Alert variant="danger" className="form-error-message">
          {errorText}
        </Alert>
      )}
      <Button
        className="form-button"
        variant={allFieldsFilled ? 'outline-success' : 'outline-primary'}
        disabled={!allFieldsFilled}
        onClick={signUpClick}
      >
        Зарегистрироваться
      </Button>{' '}
      <Footer />
    </div>
    
  );

});

export default SignUp;
