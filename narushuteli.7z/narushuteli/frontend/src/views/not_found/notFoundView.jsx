function NotFound() {
  return <div id="not-found"></div>;
}

export default NotFound;
