const { BasketProduct, Product, Basket } = require('../models/models')
const ApiError = require('../error/ApiError')

class BasketController {

    // POST http://localhost:5000/api/basket/add
    async addToBasket(req, res, next) {
        const { productId, basketId } = req.body
        try {
            const product = await Product.findByPk(productId)
            if (!product) {
                const error = new ApiError(404, 'Товар не найден')
                return next(error)
            }
            const basket = await BasketProduct.findOne({
                where: { basketId, productId }
            })
            if (basket) {
                const error = new ApiError(400, 'Товар уже добавлен в корзину')
                return next(error)
            }
            await BasketProduct.create({ basketId, productId })
            return res.json({ message: 'Товар успешно добавлен в корзину' })
        } catch (error) {
            return next(ApiError.internal(error.message))
        }
    }

    // DELETE http://localhost:5000/api/basket/remove
    async removeFromBasket(req, res, next) {
        const { productId, basketId } = req.body
        try {
            const basketProduct = await BasketProduct.findOne({
                where: { productId, basketId }
            })
            if (!basketProduct) {
                const error = new ApiError(404, 'Товар не найден в корзине')
                return next(error)
            }
            await basketProduct.destroy()
            return res.json({ message: 'Товар успешно удален из корзины' })
        } catch (error) {
            return next(ApiError.internal(error.message))
        }
    }

    // GET http://localhost:5000/api/basket/:id
    async getBasketByUserId(req, res, next) {
        const { basketId } = req.params
        try {
            const basketItems = await BasketProduct.findAll({
                where: { basketId },              
                include: [{
                    model: Product,
                    attributes: { exclude: ['createdAt', 'updatedAt'] }
                }]
            })
            const formattedBasketItems = basketItems.map(item => ({
                id: item.id,
                basketId: item.basketId,
                productId: item.productId,
                product: {
                    id: item.product.id,
                    name: item.product.name,
                    img: item.product.img,
                    price: item.product.price,
                    amount: item.product.amount,
                    size: item.product.size,
                    typeId: item.product.typeId,
                    brandId: item.product.brandId
                }
            }))
            return res.json(formattedBasketItems)
        } catch (error) {
            return next(ApiError.internal(error.message))
        }
    }

    // DELETE http://localhost:5000/api/basket/clear/:id
    async clearBasket(req, res, next) {
        const { basketId } = req.params
        try {
            const basketItems = await BasketProduct.findAll({
                where: { basketId }
            })
            if (basketItems.length === 0) {
                return res.json({ message: 'Корзина уже пуста' })
            }
            await BasketProduct.destroy({
                where: { basketId }
            })
            return res.json({ message: 'Корзина успешно очищена' })
        } catch (error) {
            return next(ApiError.internal(error.message))
        }
    }    
}

module.exports = new BasketController()
