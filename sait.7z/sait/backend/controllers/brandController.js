const { Brand } = require("../models/models");
const ApiError = require("../error/ApiError");

class BrandController {
  // POST http://localhost:5000/api/brand
  async create(req, res, next) {
    try {
      const { name } = req.body;
      const existingBrand = await Brand.findOne({ where: { name } });
      if (existingBrand) {
        throw new Error("Бренд с таким именем уже существует.");
      }
      const brand = await Brand.create({ name });
      return res.json(brand);
    } catch (error) {
      next(ApiError.badRequest(error.message));
    }
  }

  // GET http://localhost:5000/api/brand
  async getAll(req, res) {
    try {
      const brands = await Brand.findAll({
        attributes: { exclude: ["createdAt", "updatedAt"] },
      });
      return res.json(brands);
    } catch (error) {
      return res.status(500).json({ error: "Внутренняя ошибка сервера" });
    }
  }

  // DELETE http://localhost:5000/api/brand/del/:id
  async deleteBrand(req, res, next) {
    const brandId = req.params.id;
    try {
      const brand = await Brand.findByPk(brandId);
      if (!brand) {
        const error = new ApiError(404, "Бренд не найден");
        return next(error);
      }
      await brand.destroy();
      return res.json({ message: "Бренд успешно удален" });
    } catch (error) {
      return next(ApiError.internal(error.message));
    }
  }

  // PUT http://localhost:5000/api/brand/update/:id
  async updateBrand(req, res, next) {
    const brandId = req.params.id;
    const { name } = req.body;

    try {
      const brand = await Brand.findByPk(brandId);

      if (!brand) {
        const error = new ApiError(404, "Бренд не найден");
        return next(error);
      }

      const existingBrand = await Brand.findOne({ where: { name: name } });
      if (existingBrand) {
        throw new Error("Бренд с новым именем уже существует.");
      }

      brand.name = name;
      await brand.save();

      return res.json({ message: "Имя бренда успешно изменено" });
    } catch (error) {
      return next(ApiError.internal(error.message));
    }
  }
}

module.exports = new BrandController();
