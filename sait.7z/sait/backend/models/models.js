const sequelize = require("./db");
const { DataTypes } = require("sequelize");

const User = sequelize.define("user", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: { is: /^[A-Za-z\u0400-\u04FF\s-]+$/
  },
  },
  surname: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: { is: /^[A-Za-z\u0400-\u04FF\s-]+$/
  },
  },
  patronymic: {
    type: DataTypes.STRING,
    allowNull: true,
    validate: { is: /^[A-Za-z\u0400-\u04FF\s-]+$/
  },
  },
  login: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    validate: { is: /^[a-zA-Z0-9-]+$/ },
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    validate: { isEmail: true },
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: { len: [6, undefined] },
  },
  rules: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
  role: { type: DataTypes.STRING, defaultValue: "USER" },
});

const Product = sequelize.define("product", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  name: { type: DataTypes.STRING, unique: true, allowNull: false },
  description: { type: DataTypes.STRING, allowNull: false },
  img: { type: DataTypes.STRING, allowNull: false },
  year: { type: DataTypes.INTEGER, allowNull: false },
  price: { type: DataTypes.INTEGER, allowNull: false },
  amount: { type: DataTypes.INTEGER },
});

const Type = sequelize.define("type", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  name: { type: DataTypes.STRING, unique: true, allowNull: false },
});

const Brand = sequelize.define("brand", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  name: { type: DataTypes.STRING, unique: true, allowNull: false },
});

const Basket = sequelize.define("basket", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
});

const BasketProduct = sequelize.define("basket_product", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  amount: { type: DataTypes.INTEGER },
});

const Order = sequelize.define("order", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
});

const OrderProduct = sequelize.define("order_product", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  amount: { type: DataTypes.INTEGER,allowNull: false, },
});

Type.hasMany(Product);
Product.belongsTo(Type);

Brand.hasMany(Product);
Product.belongsTo(Brand);

User.hasOne(Basket);
Basket.belongsTo(User);

User.hasOne(Basket);
Basket.belongsTo(User);

Product.hasOne(BasketProduct);
BasketProduct.belongsTo(Product);

Basket.hasOne(BasketProduct);
BasketProduct.belongsTo(Basket);

User.hasMany(Order);
Order.belongsTo(User);

Order.hasOne(OrderProduct);
OrderProduct.belongsTo(Order);

Product.hasOne(OrderProduct);
OrderProduct.belongsTo(Product);

module.exports = { User, Product, Type, Brand, Basket, BasketProduct, Order, OrderProduct };
