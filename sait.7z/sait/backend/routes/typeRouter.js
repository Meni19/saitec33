const Router = require('express')
const router = new Router()
const TypeController = require('../controllers/typeController')
const checkRole = require('../middleware/checkRoleMiddleware')

router.post('/', checkRole('ADMIN'), TypeController.create)
router.delete('/del/:id', checkRole('ADMIN'), TypeController.deleteType)
router.put('/update/:id', checkRole('ADMIN'), TypeController.updateType);
router.get('/', TypeController.getAll)

// POST http://localhost:5000/api/type
// DELETE http://localhost:5000/api/type/del/:id
// GET http://localhost:5000/api/type
// PUT http://localhost:5000/api/type/update/:id

module.exports = router