const Router = require('express')
const router = new Router()
const UserController = require('../controllers/userController')
const authMiddleware = require('../middleware/authMiddleware')
const checkRole = require('../middleware/checkRoleMiddleware')

router.post('/registration', UserController.registration)
router.post('/check_email', UserController.checkEmailExists)
router.post('/login', UserController.login)

router.get('/auth', authMiddleware, UserController.check)
router.get('/:id', UserController.getUserById)
router.get('/', checkRole('ADMIN'), UserController.getAllUsers)

router.put('/:id', UserController.editUserDetails)

router.delete('/:id', checkRole('ADMIN'), UserController.deleteUser)


// POST http://localhost:5000/api/user/registration
// POST http://localhost:5000/api/user/login
// GET http://localhost:5000/api/user/auth
// DELETE http://localhost:5000/api/user/:id
// POST http://localhost:5000/api/user/emails
// get http://localhost:5000/api/user/

module.exports = router