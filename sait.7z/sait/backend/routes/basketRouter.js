const Router = require('express')
const router = new Router()
const BasketController = require('../controllers/basketController')

router.post('/add', BasketController.addToBasket)
router.delete('/remove', BasketController.removeFromBasket)
router.get('/:basketId', BasketController.getBasketByUserId)
router.delete('/clear/:basketId', BasketController.clearBasket)

// POST http://localhost:5000/api/basket/add
// DELETE http://localhost:5000/api/basket/remove
// GET http://localhost:5000/api/basket/:id
// DELETE http://localhost:5000/api/basket/clear/:id

module.exports = router