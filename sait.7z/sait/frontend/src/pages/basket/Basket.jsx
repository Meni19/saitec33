import "./BasketStyles.css";

import React, { useEffect, useState, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Context } from "../../index";
import {
  getBasketByUserId,
  removeFromBasket,
  clearBasket,
} from "@APIs/basket/BasketAPI";

const Basket = () => {
  const { user } = useContext(Context);
  const [basketItems, setBasketItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const isAuth = user.isAuth;

    if (!isAuth) {
      navigate("/login");
      return;
    }

    const fetchBasketData = async () => {
      try {
        const userId = localStorage.getItem("userId");

        if (!userId) {
          navigate("/login");
          return;
        }

        const data = await getBasketByUserId(userId);
        setBasketItems(data);
        setLoading(false);
        
      } catch (error) {
        console.error("Ошибка при получении товаров:", error);
        setLoading(false);
      }
    };

    fetchBasketData();
  }, [navigate, user.isAuth]);

  const handleRemoveFromBasket = async (productId, basketId) => {
    try {
      const updatedBasket = basketItems.filter(
        (item) => item.product.id !== productId
      );

      setBasketItems(updatedBasket);
      await removeFromBasket(productId, basketId);
    } catch (error) {
      console.error("Ошибка при удалении товара из корзины:", error);
    }
  };

  const handleClearBasket = async () => {
    try {
      await clearBasket(user.user.id);
      setBasketItems([]);
      // console.log("Корзина очищена");
    } catch (error) {
      console.error("Ошибка при очистке корзины:", error);
    }
  };

  if (loading) {
    return <p>Загрузка...</p>;
  }

  return (
    <div className="basket-page">
  {basketItems.length > 0 ? (
    <div className="basket-container">
      <ul className="basket-items">
        {basketItems.map(({ id, product }) => (
          <li className="basket-item" key={id}>
            <img
              className="basket-image"
              alt="Product"
              src={process.env.REACT_APP_API_URL + product.img}
            />
            <div className="basket-details">
              <div className="basket-name">{product.name}</div>
              <div className="basket-price">{product.price} ₽</div>
              <button
                className="basket-remove"
                onClick={() =>
                  handleRemoveFromBasket(product.id, user.user.id)
                }
              >
                Удалить
              </button>
            </div>
          </li>
        ))}
      </ul>
      <p className="busket-sum">
        Сумма товаров:{" "}
        {basketItems.reduce((sum, item) => sum + item.product.price, 0)} ₽
      </p>
      
      <button className="reset-button" onClick={handleClearBasket}>
        Очистить корзину
      </button>
      <button className="order-button">
        Оформить заказ
      </button>
    </div>
  ) : (
    <div className="empty-basket">
      <p className="basket-empty-text">Корзина пуста</p>
      <Link className="go-store" to="/store">
        К покупкам
      </Link>
    </div>
  )}
</div>
  );
};

export default Basket;
