import UserInformation from "@components/user_info/UserInfo";

function User() {
    return(
      <UserInformation />
    )
  }
  
  export default User;
  