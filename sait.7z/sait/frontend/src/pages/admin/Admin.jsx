import "./AdminStyles.css"

import React, { useContext, useState, useEffect } from "react";
import { Context } from "../../index";
import { useNavigate, Navigate } from "react-router-dom";
import { fetchTypes, createType } from "@APIs/product/TypeAPI";
import { fetchProducts, createProduct } from "@APIs/product/ProductAPI";
import { fetchBrands, createBrand } from "@APIs/product/BrandAPI";
import { getAllUsers } from "@APIs/user/UserAPI";
import Modal from "react-modal";
import NewBrand from "@components/modals/NewBrand";
import NewType from "@components/modals/NewType";
import NewProduct from "@components/modals/NewProduct";
import BrandList from "@components/lists/BrandList";
import TypeList from "@components/lists/TypeList";
import ProductList from "@components/lists/ProductList";
import UserList from "@components/lists/UserList";

function Admin() {
  const { user } = useContext(Context);
  const navigate = useNavigate();
  const [isCreateBrandModalOpen, setCreateBrandModalOpen] = useState(false);
  const [isCreateTypeModalOpen, setCreateTypeModalOpen] = useState(false);
  const [isCreateProductModalOpen, setCreateProductModalOpen] = useState(false);
  const [brands, setBrands] = useState([]);
  const [types, setTypes] = useState([]);
  const [products, setProducts] = useState([]);
  const [users, setUsers] = useState([]);

  useEffect(() => {
    Modal.setAppElement("#root");
    fetchBrandData();
    fetchTypeData();
    fetchProductData();
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      const data = await getAllUsers();
      setUsers(data || []);
    } catch (error) {
      console.error("Ошибка при получении пользователей:", error);
    }
  };

  const fetchBrandData = async () => {
    try {
      const data = await fetchBrands();
      setBrands(data || []);
    } catch (error) {
      console.error("Ошибка при получении брендов:", error);
    }
  };

  const fetchTypeData = async () => {
    try {
      const data = await fetchTypes();
      setTypes(data || []);
    } catch (error) {
      console.error("Ошибка при получении типов:", error);
    }
  };

  const fetchProductData = async () => {
    try {
      const data = await fetchProducts();
      setProducts(data || []);
    } catch (error) {
      console.error("Ошибка при получении товаров:", error);
    }
  };

  if (!(user.user.role === "ADMIN")) {
    return <Navigate to="/" />;
  }

  const openCreateBrandModal = () => {
    setCreateBrandModalOpen(true);
  };

  const closeCreateBrandModal = async (newBrand) => {
    setCreateBrandModalOpen(false);
    if (newBrand) {
      await fetchBrandData();
    }
    navigate("/admin");
  };

  const openCreateTypeModal = () => {
    setCreateTypeModalOpen(true);
  };

  const closeCreateTypeModal = async (newType) => {
    setCreateTypeModalOpen(false);
    if (newType) {
      await fetchTypeData();
    }
    navigate("/admin");
  };

  const openCreateProductModal = () => {
    setCreateProductModalOpen(true);
  };

  const closeCreateProductModal = async (newProduct) => {
    setCreateProductModalOpen(false);
    if (newProduct) {
      await fetchProductData();
    }
    navigate("/admin");
  };

  return (
    <div>
      <h1>Административная страница</h1>
      <div className="buttons-menu">
        <button className="create-button" onClick={openCreateBrandModal}>
          Создать класс
        </button>
        <button className="create-button" onClick={openCreateTypeModal}>
          Создать тип
        </button>
        <button className="create-button" onClick={openCreateProductModal}>
          Создать товар
        </button>
      </div>

      <div className="lists">
        <BrandList className="brand" brands={brands} />
        <TypeList className="type" types={types} />
      </div>
      <div className="lists">
        <ProductList className="product" products={products} />
        <UserList className="user" users={users} />
      </div>

      <NewBrand
        isOpen={isCreateBrandModalOpen}
        onRequestClose={closeCreateBrandModal}
        onCreateBrand={createBrand}
      />
      <NewType
        isOpen={isCreateTypeModalOpen}
        onRequestClose={closeCreateTypeModal}
        onCreateType={createType}
      />
      <NewProduct
        isOpen={isCreateProductModalOpen}
        onRequestClose={closeCreateProductModal}
        onCreateProduct={createProduct}
      />
    </div>
  );
}

export default Admin;
