import React from "react";
import { Link } from "react-router-dom";
import "./HomeStyles.css";

function Home() {
  return (
    <div id="mainScreen">
      <h2 className="section-title">Kompik33 — Лучшие готовые решения</h2>
      <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Сборки для любых задач:</h3>

      <div className="car-card">
        <div className="car-image">
          <div>
            <div>
              <img src="/images/kompi/1.jpg" alt="kompik"/>
            </div>
            <Link to="/store">
            <br></br> Посмотреть в каталоге
            </Link>
          </div>
        </div>

        <div className="komp-details">
          <h3 className="komp-title">Purple G10</h3>
          <p className="car-description">
          
        Премиальная основа на базе i9 14900KF и RTX 4090 с использованием топовых комплектующих от MSI и Deepcool. 
        Оптимизирован под ААА и онлайн-проекты.{" "} <br></br><br></br>
        <Link to="/store">
              Узнать больше
            </Link>
          </p>
          <div className="komp-price">
            <span className="komp-price-new">450,000 рублей</span>
            <span className="komp-price-old">465,000 рублей</span>
          </div>
        </div>
      </div>

      <div className="car-card">
        <div className="car-image">
          <div>
            <div>
            <img src="/images/kompi/2.jpg" alt="kompik"/>
            </div>
            <Link to="/store">
            <br></br> Посмотреть в каталоге
            </Link>
          </div>
        </div>

        <div className="komp-details">
          <h3 className="komp-title">Hyte WH</h3>
          <p className="car-description">
          Система на базе процессора i9 13900K и видеокарты RTX 4090 24 GB в эксклюзивном
           корпусе с панорамным обзором на комплектующие.<br></br><br></br>
        <Link to="/store">
              Узнать больше
            </Link>
          </p>
          <div className="komp-price">
            <span className="komp-price-new">440,000 рублей</span>
            <span className="komp-price-old">450,000 рублей</span>
          </div>
        </div>
      </div>

      <div className="car-card">
        <div className="car-image">
          <div>
            
            <div>
              
            <img src="/images/kompi/3.jpg" alt="kompik"/>
            
            </div>
            <Link to="/store">
            <br></br> Посмотреть в каталоге
            </Link>
          </div>
        </div>

        <div className="komp-details">
          <h3 className="komp-title">ICON North</h3>
          <p className="car-description">
          Технологии в стиле Лофт.
Корпус ПК выполнен в минималистичном стиле с использованием настоящего дуба и кожи, 
такое сочетание не оставит равнодушным настоящего ценителя роскоши. Начинка компьютера соответствует, 
связка 20-ти ядерного i7 14700K и RTX 4080 Super 16 GB обеспечит своего владельца максимальной
 производительностью в игровых и рабочих задачах. <br></br><br></br>
        <Link to="/store">
              Узнать больше
            </Link>
          </p>
          <div className="komp-price">
            <span className="komp-price-new">300,000 ₽ рублей</span>
            <span className="komp-price-old">312,000 рублей</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
