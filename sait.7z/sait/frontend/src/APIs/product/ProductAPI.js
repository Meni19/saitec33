import { $authHost, $host } from "../index";

export const createProduct = async (product) => {
  const { data } = await $authHost.post("api/product", product);
  return data;
};


export const deleteProduct = async (productId) => {
  const { data } = await $authHost.delete(`api/product/del/${productId}`);
  return data;
};

export const fetchProducts = async (brandId, typeId, limit, page) => {
  try {
    const { data } = await $host.get("api/product", {
      params: {
        brandId,
        typeId,
        limit,
        page,
      },
    });
    return data;
  } catch (error) {
    throw error;
  }
};

export const fetchOneProduct = async (id) => {
  const { data } = await $host.get("api/product/" + id);
  return data;
};
