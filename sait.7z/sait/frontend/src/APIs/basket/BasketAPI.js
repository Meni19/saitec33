import { $authHost } from "../index";
import { jwtDecode } from "jwt-decode";

export const addToBasket = async (productId, basketId) => {
  try {
    const { data } = await $authHost.post(`api/basket/add`, {
      productId,
      basketId,
    });
    return data;
  } catch (error) {
    throw new Error(`Ошибка добавления товара: ${error.message}`);
  }
};

export const removeFromBasket = async (productId, basketId) => {
  try {
    const { data } = await $authHost.delete(`api/basket/remove`, {
      data: { productId, basketId },
    });
    return data;
  } catch (error) {
    throw new Error(`Ошибка удаления товара: ${error.message}`);
  }
};

export const getBasketByUserId = async (basketId) => {
  try {
    const { data } = await $authHost.get(`api/basket/${basketId}`);
    return data;
  } catch (error) {
    throw new Error(`Ошибка получения товаров корзины: ${error.message}`);
  }
};

export const setTokenInLocalStorage = (token) => {
  try {
    if (typeof token !== 'string') {
      throw new Error("Недействительный токен");
    }
    localStorage.setItem("token", token);
  } catch (error) {
    throw new Error(`Ошибка токена в localStorage: ${error.message}`);
  }
};

export const decodeToken = (token) => {
  try {
    if (typeof token !== 'string') {
      throw new Error("Invalid token specified: must be a string");
    }
    return jwtDecode(token);
  } catch (error) {
    throw new Error(`Ошибка дешифровки токена: ${error.message}`);
  }
};

export const clearBasket = async (basketId) => {
  try {
    const { data } = await $authHost.delete(`api/basket/clear/${basketId}`);
    return data;
  } catch (error) {
    throw new Error(`Ошибка отчистки корзины: ${error.message}`);
  }
};
