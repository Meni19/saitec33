import { $authHost, $host } from "../index";
import { jwtDecode } from "jwt-decode";



export const registration = async (
  name,
  surname,
  patronymic,
  login,
  email,
  password,
  confirmPassword,
  rules,
) => {
  const { data } = await $host.post("api/user/registration", {
    name,
    surname,
    patronymic,
    login,
    email,
    password,
    confirmPassword,
    rules,
  });
  localStorage.setItem("token", data.token);
  return jwtDecode(data.token);
};

export const signin = async (login, password) => {
  const { data } = await $host.post("api/user/login", { login, password });
  localStorage.setItem("token", data.token);
  return jwtDecode(data.token);
};

export const check = async () => {
  const { data } = await $authHost.get("api/user/auth");
  localStorage.setItem("token", data.token);
  return jwtDecode(data.token);
};

export const checkEmailExists = async (email) => {
  const { data } = await $host.post("api/user/emails", { email });
  return data.exists;
};

export const getAllUsers = async () => {
  const { data } = await $authHost.get("api/user");
  return data;
};

export const getOneUser = async (id) => {
  try {
    const { data } = await $authHost.get(`api/user/${id}`);
    return data;
  } catch (error) {
    throw new Error(`Пользователь не найден: ${error.message}`);
  }
};

export const updateUser = async (id, name, surname, patronymic, login, email) => {
  try {
  const { data } = await $host.put(`api/user/${id}`, {
  name,
  surname,
  patronymic,
  login,
  email,
  });
  return data;
  } catch (error) {
  throw new Error(`Ошибка при обновлении пользователя: ${error.message}`);
  }
  };