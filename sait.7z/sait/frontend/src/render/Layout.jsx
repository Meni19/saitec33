import PagesRoutes from "./PagesRoutes";
import Footer from "@components/navigation/footer/Footer";
import Header from "@components/navigation/header/Header";

function Layout() {
  return (
    <div
      style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}
    >
      <Header />
      <div style={{ flex: 1 }}>
        <PagesRoutes />
      </div>
      <Footer />
    </div>
  );
}

export default Layout;
