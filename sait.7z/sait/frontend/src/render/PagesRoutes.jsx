import React from "react";
import { Route, Routes } from "react-router-dom";
import Home from "@pages/home/Home";
import User from "@pages/user/User";
import Admin from "@pages/admin/Admin";
import Store from "@pages/store/Store";
import Basket from "@pages/basket/Basket";
import About from "@pages/about/About";
import Contacts from "@pages/contacts/Contacts";
import LoginForm from "@components/forms/LoginForm";
import RegistrationForm from "@components/forms/RegistrationForm";
import Error from "@pages/not_found/Error";

function PagesRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/user" element={<User />} />
      <Route path="/admin" element={<Admin />} />
      <Route path="/store" element={<Store />} />
      <Route path="/basket" element={<Basket />} />
      <Route path="/about" element={<About />} />
      <Route path="/contacts" element={<Contacts />} />
      <Route path="/login" element={<LoginForm />} />
      <Route path="/registration" element={<RegistrationForm />} />
      <Route path="*" element={<Error />} />
    </Routes>
  );
}

export default PagesRoutes;
