import "./ListsStyles.css";

import React, { useState, useEffect } from "react";
import { deleteProduct, fetchProducts } from "../../APIs/product/ProductAPI";

function ProductList() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProductData = async () => {
      try {
        const data = await fetchProducts();
        setProducts(data.rows || []);
        setLoading(false);
      } catch (error) {
        console.error("Ошибка при получении товаров:", error);
        setLoading(false);
      }
    };

    fetchProductData();
  }, []);

  const handleDeleteProduct = async (productId) => {
    try {
      const confirmDelete = window.confirm(
        "Вы уверены, что хотите удалить этот товар?"
      );

      if (confirmDelete) {
        const response = await deleteProduct(productId);

        if (response.error) {
          alert(response.error);
        } else {
          const data = await fetchProducts();
          setProducts(data.rows || []);
        }
      }
    } catch (error) {
      console.error("Ошибка при удалении товара:", error);
    }
  };

  if (loading) {
    return <p>Загрузка Товаров...</p>;
  }

  return (
    <div className="main-list">
      <h2>Список товаров</h2>
      {products.length > 0 ? (
        <ul>
          {products.map((product) => (
            <li className='items-list' key={product.id}>
              <strong>{product.name}</strong> - {product.brand} - {product.type}{" "}
              <button className='delete-button' onClick={() => handleDeleteProduct(product.id)}>
                Удалить
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p>Нет доступных товаров.</p>
      )}
    </div>
  );
}

export default ProductList;
