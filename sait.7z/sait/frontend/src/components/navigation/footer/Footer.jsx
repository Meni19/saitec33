import "./FooterStyles.css";
import { Link } from "react-router-dom";

function Footer() {
  return (
    <div className="footer">
      <div className="items">
        <div className="logo">
        <Link className="small-logo" to="/">
          <img className="small-logo-image" src="/images/small1.jpg" alt="logo"/>
        </Link>
        </div>
        <Link className="contacts" to="/contacts">
          Контакты
        </Link>
        {/* <Link className="about" to="/about">
          О нас
        </Link> */}
        <div className="title">@2024 Kompik33 </div>
        <Link className="tg" to="/login">
          <img className="tg-image" src="/images/telegram.svg" alt="tg"/>
        </Link>
        <Link className="vk" to="/login">
          <img className="vk-image" src="/images/vkontakte.svg" alt="vk"/>
        </Link>
      </div>
    </div>
  );
}

export default Footer;
