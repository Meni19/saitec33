import "./BarsStyles.css";
import React, { useEffect, useState } from "react";
import { fetchTypes } from "../../APIs/product/TypeAPI";

function TypeBar({ setSelectedType, setPage }) {
  const [types, setTypes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeButton, setActiveButton] = useState(null);

  useEffect(() => {
    const fetchTypeData = async () => {
      try {
        const data = await fetchTypes();
        setTypes(data || []);
        setLoading(false);
      } catch (error) {
        console.error("Ошибка при получении типов:", error);
        setLoading(false);
      }
    };

    fetchTypeData();
  }, []);

  const handleShowAllTypes = () => {
    setSelectedType(null);
    setPage(1);
    setActiveButton(null);
  };

  const handleTypeClick = (typeId) => {
    setSelectedType(typeId);
    setPage(1);
    setActiveButton(typeId);
  };

  if (loading) {
    return <div className="bar-loading" />;
  }

  return (
    <div className="bar">
      <div className="bar-items">
        <button
          onClick={handleShowAllTypes}
          className={
            activeButton === null 
            ? "bar-button-active" 
            : "bar-button"
          }
        >
          ВСЕ ТИПЫ
        </button>
        {types.map((type) => (
          <button
            key={type.id}
            onClick={() => handleTypeClick(type.id)}
            className={
              activeButton === type.id
                ? "bar-button-active"
                : "bar-button"
            }
          >
            {type.name}
          </button>
        ))}
      </div>
    </div>
  );
}

export default TypeBar;
