import "./BarsStyles.css";
import React, { useEffect, useState } from "react";
import { fetchBrands } from "../../APIs/product/BrandAPI";

function BrandBar({ setSelectedBrand, setPage }) {
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeButton, setActiveButton] = useState(null);

  useEffect(() => {
    const fetchBrandData = async () => {
      try {
        const data = await fetchBrands();
        setBrands(data || []);
        setLoading(false);
      } catch (error) {
        console.error("Ошибка при получении брендов:", error);
        setLoading(false);
      }
    };

    fetchBrandData();
  }, []);

  const handleShowAllBrands = () => {
    setSelectedBrand(null);
    setPage(1);
    setActiveButton(null);
  };

  const handleBrandClick = (brandId) => {
    setSelectedBrand(brandId);
    setPage(1);
    setActiveButton(brandId);
  };

  if (loading) {
    return <div className="bar-loading" />;
  }

  return (
    <div className="bar">
      <div className="bar-items">
        <button
          onClick={handleShowAllBrands}
          className={
            activeButton === null
              ? "bar-button-active"
              : "bar-button"
          }
        >
          ВСЕ СБОРКИ
        </button>
        {brands.map((brand) => (
          <button
            key={brand.id}
            onClick={() => handleBrandClick(brand.id)}
            className={
              activeButton === brand.id
                ? "bar-button-active"
                : "bar-button"
            }
          >
            {brand.name}
          </button>
        ))}
      </div>
    </div>
  );
}

export default BrandBar;
