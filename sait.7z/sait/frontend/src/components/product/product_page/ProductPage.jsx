import "./ProductPageStyles.css";
import React, { useContext, useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Context } from "../../../index";
import {
  addToBasket,
  removeFromBasket,
  getBasketByUserId,
} from "@APIs/basket/BasketAPI";

const ProductPage = ({ product, onRequestClose }) => {
  const { user } = useContext(Context);
  const [isProductInBasket, setIsProductInBasket] = useState(false);

  useEffect(() => {
    const checkProductInBasket = async () => {
      if (user.isAuth && product) {
        const userId = localStorage.getItem("userId");
        const userBasket = await getBasketByUserId(userId);
        const productInBasket = userBasket.some(
          (item) => item.product.id === product.id
        );
        setIsProductInBasket(productInBasket);
      }
    };

    checkProductInBasket();
  }, [user.isAuth, product]);

  if (!product) {
    return <p>Товар не найден</p>;
  }

  const { id, name, brand, price, description } = product;

  const addToBasketClick = async () => {
    try {
      if (user.isAuth) {
        if (isProductInBasket) {
          await removeFromBasket(id, user.user.id);
          setIsProductInBasket(false);
          console.log("Товар удален из корзины");
        } else {
          const addedProduct = await addToBasket(id, user.user.id);
          console.log("Товар добавлен в корзину:", addedProduct);
          setIsProductInBasket(true);
        }
      } else {
        // console.log("Пользователь не авторизован. Перенаправляем на страницу /login");
      }
    } catch (error) {
      console.error("Ошибка при обработке товара в корзине:", error);
    }
  };

  return (
    <section id="product-modal">
      <div className="product-page-items">
        <img
          className="product-page-image"
          src={process.env.REACT_APP_API_URL + product.img}
          alt="Product"
        />
        <div className="product-page-name">{name}</div>
        <div className="product-page-description">{description}</div>
        <div className="product-page-brand">{brand}</div>
        <div className="product-page-price">{price} ₽</div>
        <div className="product-page-buttons">
          {!user.isAuth ? (
            <Link to="/login">
              <button className="product-page-button-add">
                Добавить в корзину
              </button>
            </Link>
          ) : (
            <button
              onClick={addToBasketClick}
              className={`product-page-button ${
                isProductInBasket ? "product-page-button-added" : "product-page-button-add"
              }`}
            >
              {isProductInBasket ? "Удалить из корзины" : "Добавить в корзину"}
            </button>
          )}
        </div>
        {/* <button className="product-page-close-button" onClick={onRequestClose}>
          Закрыть
        </button> */}
      </div>
    </section>
  );
};

export default ProductPage;
