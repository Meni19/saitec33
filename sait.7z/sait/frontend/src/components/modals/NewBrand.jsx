import "./ModalsStyles.css";

import React, { useState } from "react";
import Modal from "react-modal";
import { createBrand } from "../../APIs/product/BrandAPI";

function NewBrand({ isOpen, onRequestClose }) {
  const [brandName, setBrandName] = useState("");
  const [loading, setLoading] = useState(false);

  const handleCreateBrand = async () => {
    if (!brandName) {
      alert("Введите имя бренда");
      return;
    }

    try {
      setLoading(true);
      const newBrand = await createBrand({ name: brandName });
      alert(`Бренд "${newBrand.name}" успешно создан!`);
      setBrandName("");
      onRequestClose();
    } catch (error) {
      console.error("Ошибка при создании бренда:", error);
      alert("Произошла ошибка при создании бренда");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      className="modal-main"
      isOpen={isOpen}
      onRequestClose={onRequestClose}
      contentLabel="Создать новый бренд"
    >
      <h2>Создать новый бренд</h2>
      <div className="input-form">
        <label className="name-of-inputs">Имя бренда:</label>
        <input
          type="text"
          value={brandName}
          onChange={(e) => setBrandName(e.target.value)}
        />
      </div>
      <button className="create" onClick={handleCreateBrand} disabled={loading}>
        {loading ? "Создание..." : "Создать бренд"}
      </button>
    </Modal>
  );
}

export default NewBrand;
