import "./ModalsStyles.css";

import React, { useState } from "react";
import Modal from "react-modal";
import { createType } from "../../APIs/product/TypeAPI";

function NewType({ isOpen, onRequestClose }) {
  const [typeName, setTypeName] = useState("");
  const [loading, setLoading] = useState(false);

  const handleCreateType = async () => {
    if (!typeName) {
      alert("Введите имя типа");
      return;
    }

    try {
      setLoading(true);
      const newType = await createType({ name: typeName });
      alert(`Тип "${newType.name}" успешно создан!`);
      setTypeName("");
      onRequestClose();
    } catch (error) {
      console.error("Ошибка при создании типа:", error);
      alert("Произошла ошибка при создании типа");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      className="modal-main"
      isOpen={isOpen}
      onRequestClose={onRequestClose}
      contentLabel="Создать новый тип"
    >
      <h2>Создать новый тип</h2>
      <div className="input-form">
        <label className="name-of-inputs">Имя типа:</label>
        <input
          type="text"
          value={typeName}
          onChange={(e) => setTypeName(e.target.value)}
        />
      </div>
      <button className="create" onClick={handleCreateType} disabled={loading}>
        {loading ? "Создание..." : "Создать тип"}
      </button>
    </Modal>
  );
}

export default NewType;
