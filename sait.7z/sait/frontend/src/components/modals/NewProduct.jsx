import "./ModalsStyles.css";

import React, { useState, useEffect } from "react";
import Modal from "react-modal";
import { fetchTypes } from "../../APIs/product/TypeAPI"
import { fetchBrands } from "../../APIs/product/BrandAPI"
import { createProduct } from "../../APIs/product/ProductAPI";

function NewProduct({ isOpen, onRequestClose }) {
  const [productName, setProductName] = useState("");
  const [productDescription, setProductDescription] = useState("");
  const [productPrice, setProductPrice] = useState("");
  const [productAmount, setProductAmount] = useState("");
  const [productYear, setProductYear] = useState("");
  const [productSize, setProductSize] = useState("");
  const [productBrandId, setProductBrandId] = useState("");
  const [productTypeId, setProductTypeId] = useState("");
  const [productImage, setProductImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [brands, setBrands] = useState([]);
  const [types, setTypes] = useState([]);

  useEffect(() => {
    const fetchBrandsAndTypes = async () => {
      try {
        const brandsData = await fetchBrands();
        const typesData = await fetchTypes();
        setBrands(brandsData);
        setTypes(typesData);
      } catch (error) {
        console.error("Ошибка при получении данных:", error);
      }
    };

    fetchBrandsAndTypes();
  }, []);

  const handleCreateProduct = async () => {
    try {
      setLoading(true);

      if (
        !productName ||
        !productDescription ||
        !productPrice ||
        !productAmount ||
        !productYear ||
        !productSize ||
        !productBrandId ||
        !productTypeId ||
        !productImage
      ) {
        alert("Заполните все поля.");
        return;
      }

      const formData = new FormData();
      formData.append("name", productName);
      formData.append("description", productDescription);
      formData.append("price", productPrice);
      formData.append("amount", productAmount);
      formData.append("size", productSize);
      formData.append("year", productYear);
      formData.append("brandId", productBrandId);
      formData.append("typeId", productTypeId);
      formData.append("img", productImage);

      const newProduct = await createProduct(formData);

      alert(`Товар "${newProduct.name}" успешно создан`);

      setProductName("");
      setProductDescription("");
      setProductPrice("");
      setProductAmount("");
      setProductYear("");
      setProductSize("");
      setProductBrandId("");
      setProductTypeId("");
      setProductImage(null);

      onRequestClose();
    } catch (error) {
      console.error("Error creating product:", error);
      alert("Ошибка при создании товара");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      className="modal-main"
      isOpen={isOpen}
      onRequestClose={onRequestClose}
      contentLabel="Создать новый товар"
    >
      <h2>Создать товар</h2>
      <div className="input-form">
        <label className="name-of-inputs">Название</label>
        <input
          type="text"
          value={productName}
          onChange={(e) => setProductName(e.target.value)}
        />
      </div>
      <div className="input-form">
        <label className="name-of-inputs">Описание</label>
        <input
          type="text"
          value={productDescription}
          onChange={(e) => setProductDescription(e.target.value)}
        />
      </div>
      <div className="input-form">
        <label className="name-of-inputs">Цена</label>
        <input
          type="number"
          value={productPrice}
          onChange={(e) => setProductPrice(e.target.value)}
        />
      </div>
      <div className="input-form">
        <label className="name-of-inputs">Отсаток</label>
        <input
          type="number"
          value={productAmount}
          onChange={(e) => setProductAmount(e.target.value)}
        />
      </div>
      <div className="input-form">
        <label className="name-of-inputs">Размер</label>
        <input
          type="text"
          value={productSize}
          onChange={(e) => setProductSize(e.target.value)}
        />
      </div>
      <div className="input-form">
        <label className="name-of-inputs">Год</label>
        <input
          type="text"
          value={productYear}
          onChange={(e) => setProductYear(e.target.value)}
        />
      </div>
      <div className="input-form">
        <label className="name-of-inputs">Бренд</label>
        <select
          value={productBrandId}
          onChange={(e) => setProductBrandId(e.target.value)}
        >
          <option value="" disabled>
            Выбрать
          </option>
          {brands.map((brand) => (
            <option key={brand.id} value={brand.id}>
              {brand.name}
            </option>
          ))}
        </select>
      </div>
      <div className="input-form">
        <label className="name-of-inputs">Тип</label>
        <select
          value={productTypeId}
          onChange={(e) => setProductTypeId(e.target.value)}
        >
          <option value="" disabled>
            Выбрать
          </option>
          {types.map((type) => (
            <option key={type.id} value={type.id}>
              {type.name}
            </option>
          ))}
        </select>
      </div>
      <div className="input-form">
        <label className="name-of-inputs">Изображение</label>
        <input
          type="file"
          accept="image/*"
          onChange={(e) => setProductImage(e.target.files[0])}
        />
      </div>
      <button
        className="create"
        onClick={handleCreateProduct}
        disabled={loading}
      >
        {loading ? "Создание..." : "Создать товар"}
      </button>
    </Modal>
  );
}

export default NewProduct;
