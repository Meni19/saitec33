import './UserInfo.css';

import Button from 'react-bootstrap/Button';

import React, { useState } from 'react';
import { updateUser } from '@APIs/user/UserAPI';
 
const UpdateUserForm = ({ userId }) => {
const [name, setName] = useState('');
const [surname, setSurname] = useState('');
const [patronymic, setPatronymic] = useState('');

const [login, setLogin] = useState('');
const [email, setEmail] = useState('');
const [message, setMessage] = useState('');

const handleSubmit = async (event) => {
event.preventDefault();

try {
await updateUser(userId, name, surname, patronymic, login, email);
setMessage('Данные пользователя успешно обновлены');
} catch (error) {
setMessage(`Ошибка при обновлении данных: ${error.message}`);
}
};

return (
<form className="info-edit-form" onSubmit={handleSubmit}>
<h3>Изменение данных</h3>
<label className="input-info-item">
Имя:&nbsp;
<input
type="text"
value={name}
onChange={(e) => setName(e.target.value)}
/>
</label>
<label className="input-info-item">
Фамилия:&nbsp;
<input
type="text"
value={surname}
onChange={(e) => setSurname(e.target.value)}
/>
</label>
<label className="input-info-item">
Отчество:&nbsp;
<input
type="text"
value={patronymic}
onChange={(e) => setPatronymic(e.target.value)}
/>
</label>
<label className="input-info-item">
Логин:&nbsp;
<input
type="text"
value={login}
onChange={(e) => setLogin(e.target.value)}
/>
</label>
<label className="input-info-item">
Email:&nbsp; <input
type="email"
value={email}
onChange={(e) => setEmail(e.target.value)}
/>
</label>
<Button variant="success" type="submit">
Обновить данные
</Button>
{message && <p>{message}</p>}
</form>
);
};

export default UpdateUserForm;