import React, { useState, useEffect, useContext } from 'react';
import { getOneUser } from '@APIs/user/UserAPI';
import { Context } from '../../index';

import UpdateUserForm from './userinfoModal';



function UserInformation() {
  const { user } = useContext(Context);
  const [userInfo, setUserInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userId = localStorage.getItem("userId");
        const data = await getOneUser(userId);
        setUserInfo(data);
        setLoading(false);
      } catch (error) {
        console.error("Ошибка при получении информации о пользователе:", error);
        setLoading(false);
      }
    };
  
    fetchUserData();
  }, [user.id, userInfo]);
  

  const userId = localStorage.getItem("userId");

  if (loading) {
    return <p>Загрузка информации о пользователе...</p>;
  }

  if (!userInfo) {
    return <p>Пользователь не найден.</p>;
  }

  return (
    <>
    <div className='profile'>
      
      <h2>&nbsp;Информация о пользователе:</h2>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;Имя: {userInfo.user.name}</p> 
      <p>&nbsp;&nbsp;&nbsp;&nbsp;Фамилия: {userInfo.user.surname}</p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;Отчество: {userInfo.user.patronymic}</p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;Логин: {userInfo.user.login}</p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;Email: {userInfo.user.email}</p>
     
    </div>
    <div>
      <UpdateUserForm userId={userId} />
    </div>
    </>
  );
}

export default UserInformation;